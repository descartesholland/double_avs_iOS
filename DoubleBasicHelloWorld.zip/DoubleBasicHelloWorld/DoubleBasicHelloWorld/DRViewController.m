//
//  DRViewController.m
//  DoubleBasicHelloWorld
//
//  Created by David Cann on 8/3/13.
//  Copyright (c) 2013 Double Robotics, Inc. All rights reserved.
//

#import "DRViewController.h"
#import <DoubleControlSDK/DoubleControlSDK.h>

#import "DREchoHandler.h"

#import "AVS/LoginController.h"

@interface DRViewController () <DRDoubleDelegate>
@end

@implementation DRViewController

- (void)viewDidLoad {
	[super viewDidLoad];
//	[DRDouble sharedDouble].delegate = self;
	NSLog(@"SDK Version: %@", kDoubleBasicSDKVersion);
    
    NSString * client_id = @"amzn1.application-oa2-client.ccde0cdc13f54c5488a444679a472959";
    NSString * scope = @"alexa:all";
    NSString * scope_data = @"{\"alexa:all\": {\"productID\": \"echo57\",\"productInstanceAttributes\": {\"deviceSerialNumber\": \"B00X4WHP5E\"}}}";
    NSString * response_type = @"code";
    NSString * redirect_uri = @"http://128.157.15.244:8883/authresponse/";
    
    //    NSURL *url = [NSURL URLWithString:@"https://www.amazon.com/ap/oa"];
    
//    NSURL *enquiryurl = [NSURL URLWithString:[NSString stringWithFormat:@"https://www.amazon.com/ap/oa/?client_id=%@&scope=%@&scope_data=%@&response_type=%@&redirect_uri=%@",
//                                              [client_id stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
//                                              [scope stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
//                                              [scope_data stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
//                                              [response_type stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
//                                              [redirect_uri stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]]];
    
    
    NSString* urlString = [NSString stringWithFormat:@"https://www.amazon.com/ap/oa/?client_id=%@&scope=%@&scope_data=%@&response_type=%@&redirect_uri=%@",
                           [client_id stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
                           [scope stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
                           [scope_data stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
                           [response_type stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
                           redirect_uri];//[redirect_uri stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]];
    

    NSURL *add = [NSURL URLWithString:urlString];
    
    //    [[[UIApplication sharedApplication] delegate] application:[UIApplication sharedApplication] handleOpenURL:add];
//    NSLog(@"opened URL");

    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:add ];
    [urlRequest setHTTPMethod:@"POST"];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    [NSURLConnection sendAsynchronousRequest:urlRequest queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         NSLog(@"openingURL");
         [[UIApplication sharedApplication] openURL:[response URL]];
         NSLog(@"handlingOpenURL");
         [[[UIApplication sharedApplication] delegate] application:[UIApplication sharedApplication] handleOpenURL:[response URL]];
     }];

}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsPortrait(toInterfaceOrientation);
}

- (IBAction)next {
//    LoginController * loginController = [[LoginController alloc] initWithNibName:nil bundle:nil];
//    LoginController * loginController = [[[([UIApplication sharedApplication].delegate).window rootViewController] storyboard]
//                                         instantiateViewControllerWithIdentifier:@"MainStoryboard_iPad"]; //@"loginController"];
//    [self presentViewController:loginController animated:YES completion:nil];
//    
//    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"MainStoryboard_iPad" bundle:nil];
    UIViewController * buddiesOrFacebook = [[UIStoryboard storyboardWithName:@"MainStoryboard_iPad" bundle:nil]   instantiateViewControllerWithIdentifier:@"loginController"] ;
    [self presentViewController:buddiesOrFacebook animated:YES completion:nil];
}


#pragma mark - Actions
- (IBAction)toggleMic:(id)sender {
    [[DREchoHandler sharedEchoHandler] audioSwitch:true];
}

- (IBAction)poleUp:(id)sender {
	[[DRDouble sharedDouble] poleUp];
}

- (IBAction)poleStop:(id)sender {
	[[DRDouble sharedDouble] poleStop];
}

- (IBAction)poleDown:(id)sender {
	[[DRDouble sharedDouble] poleDown];
}

- (IBAction)kickstandsRetract:(id)sender {
	[[DRDouble sharedDouble] retractKickstands];
}

- (IBAction)kickstandsDeploy:(id)sender {
	[[DRDouble sharedDouble] deployKickstands];
}

- (IBAction)startTravelData:(id)sender {
	[[DRDouble sharedDouble] startTravelData];
}

- (IBAction)stopTravelData:(id)sender {
	[[DRDouble sharedDouble] stopTravelData];
}

#pragma mark - DRDoubleDelegate

- (void)doubleDidConnect:(DRDouble *)theDouble {
	statusLabel.text = @"Connected";
}

- (void)doubleDidDisconnect:(DRDouble *)theDouble {
	statusLabel.text = @"Not Connected";
}

- (void)doubleStatusDidUpdate:(DRDouble *)theDouble {
	poleHeightPercentLabel.text = [NSString stringWithFormat:@"%f", [DRDouble sharedDouble].poleHeightPercent];
	kickstandStateLabel.text = [NSString stringWithFormat:@"%d", [DRDouble sharedDouble].kickstandState];
	batteryPercentLabel.text = [NSString stringWithFormat:@"%f", [DRDouble sharedDouble].batteryPercent];
	batteryIsFullyChargedLabel.text = [NSString stringWithFormat:@"%d", [DRDouble sharedDouble].batteryIsFullyCharged];
	firmwareVersionLabel.text = [DRDouble sharedDouble].firmwareVersion;
	serialLabel.text = [DRDouble sharedDouble].serial;
}

- (void)doubleDriveShouldUpdate:(DRDouble *)theDouble {
//    NSLog(@"here");
	float drive = (driveForwardButton.highlighted) ? kDRDriveDirectionForward : ((driveBackwardButton.highlighted) ? kDRDriveDirectionBackward : kDRDriveDirectionStop);
	float turn = (driveRightButton.highlighted) ? 1.0 : ((driveLeftButton.highlighted) ? -1.0 : 0.0);
	[theDouble drive:drive turn:turn];
}

- (void)doubleTravelDataDidUpdate:(DRDouble *)theDouble {
	leftEncoderLabel.text = [NSString stringWithFormat:@"%.02f", [leftEncoderLabel.text floatValue] + [DRDouble sharedDouble].leftEncoderDeltaInches];
	rightEncoderLabel.text = [NSString stringWithFormat:@"%.02f", [rightEncoderLabel.text floatValue] + [DRDouble sharedDouble].rightEncoderDeltaInches];
	NSLog(@"Left Encoder: %f, Right Encoder: %f", theDouble.leftEncoderDeltaInches, theDouble.rightEncoderDeltaInches);
}


@end
