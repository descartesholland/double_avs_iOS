//
//  DREchoHandler.h
//  DoubleBasicHelloWorld
//
//  Created by Descartes Holland on 4/21/16.
//  Copyright © 2016 Double Robotics, Inc. All rights reserved.
//

#import "AudioProcessor.h"

@interface DREchoHandler : NSObject {
//    GCDWebServer* _webServer;
}

+ (DREchoHandler*) sharedEchoHandler;

@property (strong, nonatomic) NSString *AVS_ENDPOINT;// = @"https://avs-alexa-na.amazon.com";


@property (strong, nonatomic) NSString * AVS_TOKEN_RESPONSE_URL;// = @"https://api.amazon.com/auth/o2/token";

@property (nonatomic) NSString * accessToken;

@property (retain, nonatomic) AudioProcessor *audioProcessor;

//@property (strong, nonatomic) DRViewController *viewController;

//- (NSString *)stringForHTTPRequest;

+ (void) setAccessToken : (NSString*) token;


// actions
- (IBAction)riseGain:(id)sender;
- (IBAction)lowerGain:(id)sender;
- (void)audioSwitch:(BOOL)state;




@end
