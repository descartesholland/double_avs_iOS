//
//  DRAppDelegate.m
//  DoubleBasicHelloWorld
//
//  Created by David Cann on 8/3/13.
//  Copyright (c) 2013 Double Robotics, Inc. All rights reserved.
//

#import "DRAppDelegate.h"
#import "DRViewController.h"
#import "DREchoHandler.h"

#import "HTTP/HTTPServer.h"

#import "GCDWebServer.h"
#import "GCDWebServerDataResponse.h"


#import <LoginWithAmazon/LoginWithAmazon.h>

@implementation DRAppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.viewController = [[DRViewController alloc] initWithNibName:@"DRViewController" bundle:nil];
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    
    // Create server
    _webServer = [[GCDWebServer alloc] init];
    
    // Add a handler to respond to GET requests on any URL
    [_webServer addHandlerForMethod:@"GET" pathRegex:@"/drive/" requestClass:[GCDWebServerRequest class] processBlock:^GCDWebServerResponse *(GCDWebServerRequest* request) {
        NSLog(@"drivin");
        return [GCDWebServerResponse alloc];
    }];
    
    [_webServer addHandlerForMethod:@"GET" pathRegex:@"/authresponse/" requestClass:[GCDWebServerRequest class]
                       processBlock:^GCDWebServerResponse *(GCDWebServerRequest* request) {
                           NSLog(@"handlign");
                           
                           NSLog(@"URL: %@", [[request URL] absoluteString]);
                           
                           NSString * code = [[request query] valueForKey:@"code"];
                           NSLog(@"Code: %@", code);
                           
                           NSString * accessToken = [[request query] valueForKey:@"access_token"];
                           NSLog(@"Access token: %@", accessToken);
                           
                           
                           
                           [[DREchoHandler sharedEchoHandler] setAccessToken : accessToken];
                           BOOL isValidRedirectLogInURL = [AIMobileLib handleOpenURL:[request URL] sourceApplication:[[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleName"]];
                           NSLog(@"isValidRedirectLoginURL:%@", isValidRedirectLogInURL ? @"YES" : @"NO");
                           NSLog(@"%@", [NSString stringWithFormat:@"%@%@", @"dub://", [[request URL] absoluteString]]);
                           
                           //                                  GCDWebServerResponse* post = [[GCDWebServerResponse alloc] init]
                           GCDWebServerResponse* res = [[GCDWebServerResponse alloc] initWithRedirect:[[NSURL alloc] initWithString:[NSString stringWithFormat:@"%@%@", @"dub://", [[request URL] absoluteString]]] permanent:TRUE];
                           [res setContentType:@"application/x-www-form-urlencoded"];
                           
                           NSString * redirect_uri = @"https//localhost:8883/authresponse/";
                           
                           
                           //                                  NSString* urlString = [NSString stringWithFormat:@"https://api.amazon.com/auth/o2/token/?%@=%@&%@=%@&%@=%@&%@=%@&%@=%@&%@=%@",
                           //                                                         @"grant_type", @"authorization_code",
                           //                                                         @"code", code,
                           //                                                         @"client_id", @"amzn1.application-oa2-client.ccde0cdc13f54c5488a444679a472959",
                           //                                                         @"client_secret", @"f002f7611624bfc3b42c336056c39cfbba9185e1af54d5a82aff964dc913fdf0",
                           //                                                         @"redirect_uri", [redirect_uri stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],
                           //                                                         @"code_verifier", @"fortyfour_fortyfour_fortyfour_fortyfour_four"];//[redirect_uri stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]];
                           
                           
                           NSMutableURLRequest *postReq = [NSMutableURLRequest requestWithURL:[[NSURL alloc] initWithString: @"https://api.amazon.com/auth/o2/token/" ]];
                           [postReq setHTTPMethod:@"POST"];
                           [postReq setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
                           
                           if(code) {
                               NSDictionary* bodyParams = [NSDictionary dictionaryWithObjectsAndKeys:
                                                           @"grant_type", @"authorization_code",
                                                           @"code", code,
                                                           @"client_id", @"amzn1.application-oa2-client.ccde0cdc13f54c5488a444679a472959",
                                                           @"client_secret", @"f002f7611624bfc3b42c336056c39cfbba9185e1af54d5a82aff964dc913fdf0",
                                                           @"redirect_uri", redirect_uri,/*
                                                           @"code_verifier", @"fortyfour_fortyfour_fortyfour_fortyfour_four",*/ nil];
                               
                               //                                  [postReq setHTTPBody: [NSKeyedArchiver archivedDataWithRootObject:bodyParams] ];
                               [postReq setHTTPBody:[self httpBodyForParamsDictionary:bodyParams]];
                               
                               NSOperationQueue *queue = [[NSOperationQueue alloc] init];
                               
                               [NSURLConnection sendAsynchronousRequest:postReq queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
                                {
                                    NSLog(@"Response URL: %@", [response URL]);
                                    NSString *responseBody = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                    NSLog(@"Response body: %@", responseBody);
                                    NSLog(@"Error: %ld", (long)[error code]);
                                    
                                    if([[[response URL] absoluteString] isEqualToString:[[[DREchoHandler alloc] init] AVS_TOKEN_RESPONSE_URL] ]) {
                                        NSLog(@"Got final auth token: %@", [data base64EncodedStringWithOptions:0]);
                                    }
                                    [[HTTPServer sharedHTTPServer] start];
                                    
                                    //                                       [[UIApplication sharedApplication] openURL:[response URL]];
                                    //                                       [[[UIApplication sharedApplication] delegate] application:[UIApplication sharedApplication] handleOpenURL:[response URL]];
                                }];
                               
                               //                                  return [GCDWebServerDataResponse responseWithHTML:@"<html><body><p>Hello World</p></body></html>"];
                           }
                           return res;
                           
                       }];
    
    NSMutableDictionary* options = [NSMutableDictionary dictionary];
    [options setObject:[NSNumber numberWithInteger:8883] forKey:GCDWebServerOption_Port];
    [options setValue:nil forKey:GCDWebServerOption_BonjourName];
    [options setObject:@NO forKey:GCDWebServerOption_AutomaticallySuspendInBackground];
    [_webServer startWithOptions:options error:NULL];
    
    // Start server on port 8080
    //    [_webServer startWithPort:8080 bonjourName:nil];
    NSLog(@"Visit %@ in your web browser", _webServer.serverURL);
    
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url : (NSDictionary<NSString *, id> *)options {
    NSLog(@"openURL");
    NSLog(@"%@", [url absoluteString]);
    // Pass on the url to the SDK to parse authorization code from the url.
    BOOL isValidRedirectLogInURL = [AIMobileLib handleOpenURL:url sourceApplication:[[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleName"]];
    
    //    if(!isValidRedirectLogInURL) {
    //        return NO;
    //    }
    
    
    // App may also want to handle url
    return YES;
}

- (NSData *)httpBodyForParamsDictionary:(NSDictionary *)paramDictionary
{
    NSMutableArray *parameterArray = [NSMutableArray array];
    
    [paramDictionary enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        NSString *param = [NSString stringWithFormat:@"%@=%@", key, [self percentEscapeString:obj]];
        [parameterArray addObject:param];
    }];
    
    NSString *string = [parameterArray componentsJoinedByString:@"&"];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}

- (NSString *)percentEscapeString:(NSString *)string
{
    NSString *result = CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                                 (CFStringRef)string,
                                                                                 (CFStringRef)@" ",
                                                                                 (CFStringRef)@":/?@!$&'()*+,;=",
                                                                                 kCFStringEncodingUTF8));
    return [result stringByReplacingOccurrencesOfString:@" " withString:@"+"];
}


- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    
    NSLog(@"handleOpenURL %@",[url absoluteString]);
    
    BOOL isValidRedirectLogInURL = [AIMobileLib handleOpenURL:url sourceApplication:[[NSBundle mainBundle] bundleIdentifier]];
    
    if(isValidRedirectLogInURL)
        NSLog(@"true");
    else
        NSLog(@"false");
    
    //    if(!isValidRedirectLogInURL) {
    //        return NO;
    //    }
    
    
    // App may also want to handle url
    return YES;
}



- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    NSLog(@"stopping");
    //    [[HTTPServer sharedHTTPServer] stop];
}


@end
