//
//  DRAppDelegate.h
//  DoubleBasicHelloWorld
//
//  Created by David Cann on 8/3/13.
//  Copyright (c) 2013 Double Robotics, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GCDWebServer.h"
#import "GCDWebServerDataResponse.h"
#import "DREchoHandler.h"

@class DRViewController;

@interface DRAppDelegate : UIResponder <UIApplicationDelegate> {
    GCDWebServer* _webServer;
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) DRViewController *viewController;

//- (NSString *)stringForHTTPRequest;

@end
