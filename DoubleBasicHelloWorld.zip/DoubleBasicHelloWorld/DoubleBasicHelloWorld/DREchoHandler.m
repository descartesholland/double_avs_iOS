//
//  DREchoHandler.m
//  DoubleBasicHelloWorld
//
//  Created by Descartes Holland on 4/21/16.
//  Copyright © 2016 Double Robotics, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DREchoHandler.h"
#import "AudioProcessor.h"

@implementation DREchoHandler

@synthesize audioProcessor;

//NSString *AVS_ENDPOINT = @"https://avs-alexa-na.amazon.com";
//NSString * AVS_TOKEN_RESPONSE_URL = @"https://api.amazon.com/auth/o2/token";
BOOL audioListening = NO;

-(id)init
{
    self = [super init];
    if(self)
    {
        self.AVS_ENDPOINT = @"https://avs-alexa-na.amazon.com";
        self.AVS_TOKEN_RESPONSE_URL = @"https://api.amazon.com/auth/o2/token";
        self.accessToken = @"";
    }
    return self;
}

+(void) setAccessToken:(NSString *)token {
    self.accessToken = token;
}

#pragma mark Gain control

// gain factor += 1
- (IBAction)riseGain:(id)sender {
    if (audioProcessor == nil) return;
    [audioProcessor setGain: [audioProcessor getGain]+1.0f];
//    [self setGainLabelValue:[audioProcessor getGain]];
}

// gain factor -= 1
- (IBAction)lowerGain:(id)sender {
    if (audioProcessor == nil) return;
    [audioProcessor setGain: [audioProcessor getGain]-1.0f];
//    [self setGainLabelValue:[audioProcessor getGain]];
}

/*
 Switchtes AudioUnit from AudioProcessor on and off.
 Checks if processor exists. If not it will initialized.
 
 Nevermind that indicator and label stuff. I like it a bit fancy ;)
 */
- (void)audioSwitch {
    if (audioListening) {
        NSLog(@"Stopping AudioUnit");
        [audioProcessor stop];
        NSLog(@"AudioUnit stopped");
        audioListening = false;
    } else {
        if (audioProcessor == nil) {
            audioProcessor = [[AudioProcessor alloc] init];
        }
        NSLog(@"Starting up AudioUnit");
        [audioProcessor start];
        NSLog(@"AudioUnit running");
        audioListening = true;
    }
//    [self performSelector:@selector(showLabelWithText:) withObject:@"" afterDelay:3.5];
}

+ (DREchoHandler*) sharedEchoHandler {
    static DREchoHandler *myInstance = nil;
    if (myInstance == nil) {
        myInstance = [[[self class] alloc] init];
    }
    return myInstance;
}


@end